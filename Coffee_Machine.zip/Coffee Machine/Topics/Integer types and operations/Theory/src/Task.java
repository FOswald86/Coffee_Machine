// You can experiment here, it won’t be checked

public class Task {
  public static void main(String[] args) {
    // put your code here
  }
}
